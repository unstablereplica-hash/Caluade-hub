package com.example.walkie

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.MotionEvent
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var join: Button
    private lateinit var ptt: Button
    private lateinit var mute: Button
    private lateinit var leave: Button
    private lateinit var name: EditText
    private lateinit var channel: EditText
    private lateinit var password: EditText

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.all { it }) { startWalkie() } else { status.text = "Please allow all permissions (mic, nearby devices)" }
    }

    @SuppressLint("ClickableViewAccessibility", "SetTextI18n")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("walkie", Context.MODE_PRIVATE)
        fun et(hint: String) = EditText(this).apply { this.hint = hint; setSingleLine() }
        name = et("Your name").apply { setText(prefs.getString("name", "")) }
        channel = et("Channel name").apply { setText(prefs.getString("channel", "")) }
        password = et("Password (optional = private)").apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        join = Button(this).apply { text = "Join channel"; setOnClickListener { askPerms() } }
        status = TextView(this).apply { text = "Works with no internet — phones must be nearby."; textSize = 16f }
        ptt = Button(this).apply { text = "HOLD TO TALK"; textSize = 22f; height = 500; visibility = android.view.View.GONE
            setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> send(WalkieService.TALK_ON)
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> send(WalkieService.TALK_OFF)
                }; true } }
        mute = Button(this).apply { text = "Mute / Unmute"; visibility = android.view.View.GONE; setOnClickListener { send(WalkieService.MUTE_TOGGLE) } }
        leave = Button(this).apply { text = "Leave"; visibility = android.view.View.GONE
            setOnClickListener { send(WalkieService.STOP); showJoined(false) } }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48)
            listOf(name, channel, password, join, status, ptt, mute, leave).forEach { addView(it) } })
        WalkieService.onStatus = { status.text = it }
        showJoined(WalkieService.running)
    }

    private fun askPerms() {
        if (name.text.isBlank() || channel.text.isBlank()) { status.text = "Enter a name and channel"; return }
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 31) p += listOf(Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_ADVERTISE, Manifest.permission.BLUETOOTH_CONNECT)
        else p += Manifest.permission.ACCESS_FINE_LOCATION
        if (Build.VERSION.SDK_INT >= 33) p += listOf(Manifest.permission.NEARBY_WIFI_DEVICES, Manifest.permission.POST_NOTIFICATIONS)
        perms.launch(p.toTypedArray())
    }

    private fun startWalkie() {
        getSharedPreferences("walkie", Context.MODE_PRIVATE).edit()
            .putString("name", name.text.toString()).putString("channel", channel.text.toString()).apply()
        startForegroundService(Intent(this, WalkieService::class.java).setAction(WalkieService.START)
            .putExtra("name", name.text.toString().trim()).putExtra("channel", channel.text.toString().trim())
            .putExtra("password", password.text.toString()))
        showJoined(true)
    }

    private fun send(a: String) = startService(Intent(this, WalkieService::class.java).setAction(a))

    private fun showJoined(on: Boolean) {
        val v = if (on) android.view.View.VISIBLE else android.view.View.GONE
        ptt.visibility = v; mute.visibility = v; leave.visibility = v
        join.visibility = if (on) android.view.View.GONE else android.view.View.VISIBLE
    }
}
