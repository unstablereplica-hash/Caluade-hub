package com.example.walkie

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.*
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.ConcurrentHashMap
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Foreground service: keeps listening/talking with the screen locked, fully offline. */
class WalkieService : Service() {
    companion object {
        const val START = "start"; const val STOP = "stop"
        const val TALK_ON = "talk_on"; const val TALK_OFF = "talk_off"; const val TALK_TOGGLE = "talk_toggle"
        const val MUTE_TOGGLE = "mute_toggle"
        var onStatus: ((String) -> Unit)? = null
        var running = false
        private const val RATE = 16000
        private const val CHUNK = 3200 // ~100 ms of 16-bit mono PCM
    }

    private val client by lazy { Nearby.getConnectionsClient(this) }
    private var key: SecretKeySpec? = null
    private var channel = ""; private var myName = "Me"
    private val myId = "%04x".format(SecureRandom().nextInt(65536))
    private val peers = ConcurrentHashMap<String, String>()   // endpointId -> display name
    private val pending = ConcurrentHashMap<String, String>()
    @Volatile private var talking = false
    @Volatile private var muted = false
    private var track: AudioTrack? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            START -> start(i.getStringExtra("channel")!!, i.getStringExtra("password") ?: "", i.getStringExtra("name") ?: "Me")
            STOP -> { shutdown(); return START_NOT_STICKY }
            TALK_ON -> setTalking(true)
            TALK_OFF -> setTalking(false)
            TALK_TOGGLE -> setTalking(!talking)
            MUTE_TOGGLE -> { muted = !muted; status(if (muted) "Muted" else "Listening"); notif() }
        }
        return START_STICKY
    }

    private fun start(ch: String, pw: String, name: String) {
        if (running) return
        running = true; channel = ch; myName = name
        // Password -> AES key. Same channel name + same password = can hear each other.
        val spec = PBEKeySpec(pw.toCharArray(), ch.toByteArray(), 100_000, 256)
        key = SecretKeySpec(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded, "AES")
        val serviceId = "walkie." + MessageDigest.getInstance("SHA-256").digest(ch.toByteArray())
            .joinToString("") { "%02x".format(it) }.take(16)

        val type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
        ServiceCompat.startForeground(this, 1, buildNotif(), type)

        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(RATE)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(CHUNK * 8).setTransferMode(AudioTrack.MODE_STREAM).build().also { it.play() }

        val endpoint = "$name|$myId"
        client.startAdvertising(endpoint, serviceId, connCb,
            AdvertisingOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build())
        client.startDiscovery(serviceId, object : EndpointDiscoveryCallback() {
            override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
                // Only the side with the smaller id initiates, avoiding double connections.
                if (myId < info.endpointName.substringAfter('|')) client.requestConnection(endpoint, id, connCb)
            }
            override fun onEndpointLost(id: String) {}
        }, DiscoveryOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build())
        status("Listening on \"$ch\" — looking for nearby phones")
    }

    private val connCb = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            pending[id] = info.endpointName.substringBefore('|')
            client.acceptConnection(id, payloadCb)
        }
        override fun onConnectionResult(id: String, r: ConnectionResolution) {
            if (r.status.isSuccess) { peers[id] = pending[id] ?: "Someone"; status("Connected: ${peers.values.joinToString()}") }
        }
        override fun onDisconnected(id: String) { peers.remove(id); status("Listening — ${peers.size} nearby") }
    }

    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, p: Payload) {
            if (muted || p.type != Payload.Type.BYTES) return
            val pcm = try { crypt(false, p.asBytes()!!) } catch (e: Exception) { return } // wrong password -> dropped
            track?.write(pcm, 0, pcm.size)
            status("${peers[id] ?: "Someone"} is talking…")
        }
        override fun onPayloadTransferUpdate(id: String, u: PayloadTransferUpdate) {}
    }

    private fun setTalking(on: Boolean) {
        if (on == talking || !running) return
        talking = on; notif()
        if (!on) { status(if (muted) "Muted" else "Listening"); return }
        status("Talking…")
        Thread {
            val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, CHUNK * 2))
            val buf = ByteArray(CHUNK)
            rec.startRecording()
            while (talking) {
                val n = rec.read(buf, 0, CHUNK)
                if (n > 0 && peers.isNotEmpty())
                    client.sendPayload(peers.keys.toList(), Payload.fromBytes(crypt(true, buf.copyOf(n))))
            }
            rec.stop(); rec.release()
        }.start()
    }

    private fun crypt(encrypt: Boolean, data: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        return if (encrypt) {
            val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
            c.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv)); iv + c.doFinal(data)
        } else {
            c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, data.copyOfRange(0, 12)))
            c.doFinal(data, 12, data.size - 12)
        }
    }

    private fun status(s: String) { android.os.Handler(mainLooper).post { onStatus?.invoke(s) } }

    private fun act(a: String, code: Int) = PendingIntent.getService(this, code,
        Intent(this, WalkieService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun buildNotif(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("walkie", "Walkie", NotificationManager.IMPORTANCE_LOW))
        return NotificationCompat.Builder(this, "walkie").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Walkie · $channel").setContentText(if (muted) "Muted" else "Listening")
            .setOngoing(true).setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(0, if (talking) "Stop talking" else "Talk", act(TALK_TOGGLE, 1))
            .addAction(0, if (muted) "Unmute" else "Mute", act(MUTE_TOGGLE, 2))
            .addAction(0, "Leave", act(STOP, 3)).build()
    }
    private fun notif() = getSystemService(NotificationManager::class.java).notify(1, buildNotif())

    private fun shutdown() {
        talking = false; running = false
        client.stopAllEndpoints(); client.stopAdvertising(); client.stopDiscovery()
        track?.stop(); track?.release(); track = null; peers.clear()
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
        status("Left channel")
    }
    override fun onDestroy() { if (running) shutdown(); super.onDestroy() }
}
